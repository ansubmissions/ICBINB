## ---- echo=TRUE, eval=TRUE, message=FALSE, warning=FALSE----------------------
set.seed(1)
# loading deepMFA
library(deepMFA)

## ---- echo=TRUE, eval=TRUE, message=FALSE, warning=FALSE----------------------

library("mlbench")
p <- mlbench.smiley(n=1000, sd1 = 0.45, sd2 = 0.35)
plot(p)

noise <- rnorm(1000, 0, 0.5)
M <- cbind(p$x,noise)

## ---- echo=TRUE, eval=TRUE, message=FALSE, warning=FALSE----------------------
num.layers <- 2
k <- c(4,2)
r <- c(2,1)
init = "kmeans"

dmfa <- deepMFA::deep.mfa(M, k, r, num.layers, 25, init)
km <- kmeans(M,4)

## ---- echo=TRUE, eval=TRUE, message=FALSE, warning=FALSE----------------------
ari.deepMFA <- mclust::adjustedRandIndex(max.col(dmfa$ps.y), p$classes)
ari.kmeans <- mclust::adjustedRandIndex(km$cluster,p$classes)


