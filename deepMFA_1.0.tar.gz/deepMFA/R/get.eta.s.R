get.eta.s <- function(eta.list,Lambda.list,l,layers,k.comb,i){
	if(l==layers){
		return(eta.list[[l]][,k.comb[i,l]])	
	}
	else{
		result = eta.list[[l]][,k.comb[i,l]] + Lambda.list[[l]][k.comb[i,l],, ] %*% 
			get.eta.s(eta.list,Lambda.list,l+1,layers,k.comb,i)
		return(result)
	}
}