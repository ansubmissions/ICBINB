get.mu.tilde <- function(eta.list, Lambda.list, r, kis, l, num.layers){
  # We have to know s !
  # Take into account when mu.tilde = 0
  if ( l == num.layers ){
    mu.tilde <- array(rep(0, r[l]), c(r[l],1))
    return(mu.tilde)
  }
  else{
    mu.tilde <- array(0, c(r[l],1))
    kp1i  = kis[2]
    mu.tilde <- mu.tilde + eta.list[[l+1]][,kp1i] + 
      Lambda.list[[l+1]][kp1i,,] %*% 
      get.mu.tilde(eta.list, Lambda.list, r, kis[-1], l+1, num.layers) # see matrix() + maybe change order of index
    
    return(mu.tilde)
  }
}
