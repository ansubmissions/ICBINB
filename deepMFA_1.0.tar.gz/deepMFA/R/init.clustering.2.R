init.clustering.2 <- function(data, k.comb, init="kmeans2"){
  
  k <- dim(k.comb)[1]
  s <- sample( 1:k, dim(data)[1], replace = T)
  
  
  if ( k == 1 ) {
    s <- rep(1, dim(data)[1])
    return(s)
  }
  
  if ( init == 'kmeans2' ){
    s <- kmeans(data, k, iter.max = 200, nstart = 30,
                algorithm = "Hartigan-Wong")$cluster
    return(s)
  }
  
  if ( init == 'mclust2' ){
    require(mclust)
    mclust.options(hcUse = "SVD")
    s <- Mclust(data, G=k, verbose=FALSE)$cl
    #s <- sample( 1:k, dim(data)[1], replace = T)
    return(s)
  }
  
  return(s)
  
}