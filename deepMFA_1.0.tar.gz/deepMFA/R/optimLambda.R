optimLambda <- function (logpdf, mode, ...) 
{
  options(warn=-1)


  fit <- tryCatch(
          optim(mode, logpdf, gr = NULL, ..., 
            method="Nelder-Mead",
            hessian=FALSE,
            control=list(fnscale=-1)),
            warning = function(w) {
            print(w); 
           },
           error = function(e) {
            print(e); 
            logpdf(mode,..., verbose=T)

  })

  
  #fit=optim(mode, logpdf, gr = NULL, ..., hessian=TRUE,
  #          control=list(fnscale=-1))
  options(warn=0)
  mode=fit$par
  #h=-solve(fit$hessian, tol = 1e-18)
  p=length(mode)
  #int = p/2 * log(2 * pi) + 0.5 * log(det(h)) +
  #  logpdf(mode, ...)
  stuff = list(mode = mode,# var = h, # int = int, 
               converge=fit$convergence==0)   
  return(stuff)
}