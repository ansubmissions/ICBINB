deep.mfa <- function(data,
                     k,
                     r,
                     num.layers,
                     nb.iter,
                     init="kmeans",
                     nb.burnin = 0,
                     true.clust=0,
                     strategy.init=FALSE,
                     rate.strat=0,                      
                     parsimony="uuu",
                     rot.bool=FALSE,
                     rot.type="procrustes",
                     init.params=NULL, 
                     zl.list=NULL,
                     zl.list.percentage=100, 
                     newton.raphson=FALSE,
                     same.lambda=FALSE,
                     upper.tri.lambda=FALSE,
                     diag.lam.psi.lam=FALSE,
                     verbose=FALSE,
                     ret.params.iterations=FALSE){
  
  pb <- progress::progress_bar$new(total = nb.iter+2)
  
  numobs <- nrow(data)
  N <- nrow(data)
  p <- ncol(data)
  R <- c(p,r)
  # we have r = c(dim1, dim2,...,dimh)
  # and R = c(dim0, dim1,...,dimh) with dim0 = p

  if("kmeans2"==init || "mclust2"==init){
    k.comb = get.k.comb(k)
    s <- init.clustering.2(data, k.comb, init)
  }
  
  
  ### INITIALIZATION #### init Lambda, psi, eta, z what about s?
  lst <- list(pis = list(), Lambda = list(), eta = list(), psi = list(), psi.inv = list(), z = list()) # z to delete afterwards
  
  params.iterations <- vector("list", length = nb.iter)
  zl.return <- vector("list", length = num.layers)

  for (l in 1 : num.layers) {
    if(is.null(init.params)){
      if (l == 1) {
        z_l <- data
      } 
      else {
        #z_l <- z[, 1 : r[l-1], drop = FALSE]
        z_l <- matrix(data[, sample(1 :r[l], r[l-1], replace=T)], nrow = numobs, ncol = r[l-1])
      }
      
      # provide initial parititioning of the observations
      if(init != "kmeans2" && init != "mclust2"){
        s <- init.clustering(z_l, k, l, init)
      }
  
      # initialize parameters using factor analysis of covariance matrix
      if(init=="kmeans2" || init=="mclust2"){
        lst_l <- init.mfa(z_l, k.comb[s,l], k, r, l)
      }
      else{
        lst_l <- init.mfa(z_l, s, k, r, l)
      }
      
      lst$pis[l] <- list(lst_l$pis)
      lst$Lambda[l] <- list(lst_l$Lambda)
      lst$eta[l] <- list(lst_l$eta)
      lst$psi[l] <- list(lst_l$psi)
      lst$psi.inv[l] <- list(lst_l$psi.inv)
      lst$z[l] <- list(lst_l$z)
      z <- lst_l$z
    }
    else{# in  the case we start with some parameters

      lst$pis[l] <- list(init.params$pis[[l]])
      lst$Lambda[l] <- list(init.params$Lambda[[l]])
      lst$eta[l] <- list(init.params$eta[[l]])
      lst$psi[l] <- list(init.params$psi[[l]])
      lst$psi.inv[l] <- list(init.params$psi.inv[[l]])
    }
    
  } # end for (l in 1 : num.layers) 
  
  # progress bar
  pb$tick()
  
  pis.list = lst$pis
  psi.list = lst$psi
  psi.inv.list = lst$psi.inv
  eta.list = lst$eta
  Lambda.list = lst$Lambda
  z.list = lst$z


  lik.out <- compute.likelihood(data=data,
                                k=k,
                                eta.list=eta.list,
                                Lambda.list=Lambda.list,
                                psi.list=psi.list,
                                pis.list=pis.list,
                                iteration=0,
                                nb.burnin=nb.burnin,
                                strategy.init=strategy.init,
                                rate.strat=rate.strat)
  py <- lik.out$py
  ps.y <- lik.out$ps.y
  ps.y.list <- lik.out$ps.y.list
  hard.ps.y.list <- lik.out$hard.ps.y.list
  s <- lik.out$s 

  
  z.list <- NULL # TODO: see what's happening there
  
  ### SEM ALGORITHM ####
  
  # progress bar
  pb$tick()

  aris <- c() # evolution of ARI over iteration
  bics <- c() # evolution of BIC (or likelihood) over iterations
  

  rotations <- vector("list", length = num.layers)

  idx.sample <- 0 # useful when zl.list is nt null

  for(iteration in 1:nb.iter){


    for(l in 1:num.layers){
      
      zlm1 <- matrix(0, numobs, R[l])
      zlm1.prob <- matrix(0, numobs, R[l])
      if(1==l){
        zlm1 <- data
        zlm1.prob <- data
      }
      else{
        zlm1 <- z.list[[l - 1]]
        zlm1.prob <- matrix(0, numobs, R[l])
        

        if(is.null(zl.list)){ # when fixing the latent scores
          for (klm1i in 1 : k[l - 1]) {
            zlm1.prob <- zlm1.prob + matrix(zlm1[klm1i,,] *
                                                array(hard.ps.y.list[[l-1]][, klm1i],
                                                      c(numobs, R[l])), numobs, R[l])

          }
        }
        else{
          zlm1.prob <- zl.list[[l-1]]
        }
             
      }

      

        rho_l <- array(0, c(numobs, r[l], k[l:num.layers])) # \rho_{k_l...k_h}
        sample.z_l <- array(0, c(numobs, r[l], k[l:num.layers])) # sample N(0, \zeta_{k_l...k_h}) + \rho_{k_l...k_h}
        expectation.zz.given.s <- array(0, c(numobs, r[l], r[l], k[l:num.layers])) # \rho_{k_l...k_h} x \rho_{k_l...k_h}^T + \zeta_{k_l...k_h}
        
        rho_l.ps_zlm1 <- array(0, c(numobs, r[l], k[l]))
        sample.z_l.ps_zlm1 <- array(0, c(numobs, r[l], k[l]))
        expectation.zz.given.s.ps_zlm1 <- array(0, c(numobs, r[l], r[l], k[l]))
      
      
        ### computing \rho, \rho * \rho^t and zeta for each path
        k.prod = prod(k[l:num.layers])
        k.comb = get.k.comb(k[l:num.layers])
        #print("k.comb")
        #print(k.comb)
        kis <- rep(0,num.layers-l+1)
        for(k.iter in 1:k.prod){
          # here, we are in one path, to know which one, we compute kis
          kis <- k.comb[k.iter,]

        
             # computing sigma.tilde 
             #print(Lambda.list)
             sigma.tilde = get.sigma.tilde(psi.list, Lambda.list, r, kis, l, num.layers)
             mu.tilde  = get.mu.tilde(eta.list, Lambda.list, r, kis, l, num.layers)
             zeta.inv = ginv(sigma.tilde) + 
               t(Lambda.list[[l]][kis[1],,]) %*% 
               ginv(psi.list[[l]][kis[1],,]) %*% 
               Lambda.list[[l]][kis[1],,]
             zeta = ginv(zeta.inv)


             if (!isSymmetric(zeta)) {
               zeta <- makeSymm(zeta)
             }
             if (!is.positive.definite(zeta)) {
               zeta <- make.positive.definite(zeta)
             }
             # \rho = \zeta %*% [expression], expression = b
             b = t(Lambda.list[[l]][kis[1],,]) %*% 
               ginv(psi.list[[l]][kis[1],,]) %*%
               ( t(zlm1.prob) - matrix(eta.list[[l]][,kis[1]], R[l], numobs) ) + # here using R makes sense bc we need r[l-1]
               ginv(sigma.tilde) %*% matrix(mu.tilde, r[l], numobs)
             
             rho = zeta %*% b
              
             # when fixing some latent scores
            if(!is.null(zl.list)){ # rho <- t(zl.list[[l]])
              if(iteration==1){
                nb.sample <- round((zl.list.percentage/100) * numobs)
                idx.sample <- sample(1:numobs, nb.sample, replace=FALSE)
              }              
              rho[,idx.sample] = t(zl.list[[l]][idx.sample,])
            } 
             

             rho.rhot = array(apply(rho, 2, function(x) x %*% t(x)),
                              c(r[l], r[l], numobs))
             
             
             ## expectation.zz.given.s 
             ARGS <- vector("list", length = length(dim(expectation.zz.given.s)))
             ARGS[[1]] <- 1:numobs
             ARGS[[2]] <- 1:r[l]
             ARGS[[3]] <- 1:r[l]
             ARGS[4:length(ARGS)] <- kis
             aperm.zeta.rhorhot <- aperm(array(zeta,c(r[l], r[l], numobs)) +
                                           rho.rhot, c(3, 1, 2))
             expectation.zz.given.s.tmp <- expectation.zz.given.s
             expectation.zz.given.s <- do.call("[<-", c(list(expectation.zz.given.s.tmp),ARGS,list(aperm.zeta.rhorhot)))
             
             ## sample.z_l
             ARGS <- vector("list", length = length(dim(sample.z_l)))
             ARGS[[1]] <- 1:numobs
             ARGS[[2]] <- 1:r[l]
             ARGS[3:length(ARGS)] <- kis
             rmvnorm.rho <- mvtnorm::rmvnorm(numobs, rep(0, r[l]), zeta) + t(rho)
             sample.z_l.tmp <- sample.z_l 
             sample.z_l <- do.call("[<-", c(list(sample.z_l.tmp),ARGS,list(rmvnorm.rho)))#rmvnorm.rho
             
             ## rho_l
             ARGS <- vector("list", length = length(dim(rho_l)))
             ARGS[[1]] <- 1:numobs
             ARGS[[2]] <- 1:r[l]
             ARGS[3:length(ARGS)] <- kis
             rho_l.tmp <- rho_l
             rho_l <- do.call("[<-", c(list(rho_l.tmp),ARGS,list(t(rho)))) 


             if(l == num.layers){
               rho_l.ps_zlm1[,,kis] <- t(rho)
               sample.z_l.ps_zlm1[,,kis] <- rmvnorm.rho
               expectation.zz.given.s.ps_zlm1[,,,kis] <- aperm.zeta.rhorhot
             }
             
           } # end for(k.iter in 1:k.prod){ --> is equivalent to several loops on all ki of k
           
           
           # filling with probs:
           if(l != num.layers){
             
             k.prod = prod(k[(l+1):num.layers])
             k.comb = get.k.comb(k[(l+1):num.layers])
             
             for(k.iter in 1:k.prod){
               kis <- k.comb[k.iter,]
               prob <- get.prob.ps.y(hard.ps.y.list, kis, l, num.layers)


               ## rho_l
               ARGS <- vector("list", length = length(dim(rho_l)) )
               ARGS[[1]] <- 1:numobs
               ARGS[[2]] <- 1:r[l]
               ARGS[[3]] <- 1:k[l]
               ARGS[4:length(ARGS)] <- kis
               
               rho_l.tmp <- do.call("[", c(list(rho_l),ARGS))
               rho_l.ps_zlm1 <- rho_l.ps_zlm1 + rho_l.tmp * array( prob, c(numobs, r[l], k[l]) )


               
               # sample.z_l
               ARGS <- vector("list", length = length(dim(sample.z_l)) )
               ARGS[[1]] <- 1:numobs
               ARGS[[2]] <- 1:r[l]
               ARGS[[3]] <- 1:k[l]
               ARGS[4:length(ARGS)] <- kis
               
               sample.z_l.tmp <- do.call("[", c(list(sample.z_l),ARGS))
               sample.z_l.ps_zlm1 <- sample.z_l.ps_zlm1 + sample.z_l.tmp * array( prob, c(numobs, r[l], k[l]) )
               
               # expectation.zz.given.s
               ARGS <- vector("list", length = length(dim(expectation.zz.given.s)) )
               ARGS[[1]] <- 1:numobs
               ARGS[[2]] <- 1:r[l]
               ARGS[[3]] <- 1:r[l]
               ARGS[[4]] <- 1:k[l]
               ARGS[5:length(ARGS)] <- kis
               
               expectation.zz.given.s.tmp <- do.call("[", c(list(expectation.zz.given.s),ARGS))
               expectation.zz.given.s.ps_zlm1 <- expectation.zz.given.s.ps_zlm1 + 
                 expectation.zz.given.s.tmp * array( prob, c(numobs, r[l], r[l], k[l]) )

             } # end of second for(k.iter in 1:k.prod){


             
           } # end of if(l != num.layers){

          
        z.list[[l]] <- aperm(sample.z_l.ps_zlm1, c(3, 1, 2))


        out <- list()

        rot <- rot.bool & is.null(zl.list) & (iteration > nb.burnin)

        same.lambda.v = FALSE
        if(same.lambda && (iteration > nb.burnin)){
            same.lambda.v=TRUE
        }




        if(!newton.raphson || (iteration %% 2 == 1)){
          out  <- compute.est(k_l=k[l], 
                              r_lm1=R[l], 
                              r_l=r[l], 
                              ps.y.list_l=hard.ps.y.list[[l]], 
                              zlm1.prob=zlm1.prob,
                              rho_l.ps_zlm1=aperm(rho_l.ps_zlm1, c(3, 1, 2)), 
                              expectation.zz.given.s.ps_zlm1=aperm(expectation.zz.given.s.ps_zlm1, c(4, 3, 2, 1)), 
                              eta.list_l=eta.list[[l]],
                              lambda.list_l=Lambda.list[[l]],
                              psi.list_l=psi.list[[l]],
                              parsimony=parsimony,                            
                              rot=rot,
                              rot.type=rot.type,
                              same.lambda=same.lambda.v, # if fixing lambda like iter -1 
                              upper.tri.lambda=upper.tri.lambda,
                              diag.lam.psi.lam=diag.lam.psi.lam                               
                              )
        }
        else{
          out <- compute.est.newton(k=k,
                                    R=R,
                                    r=r,
                                    ps.y.list=ps.y.list,
                                    zlm1.prob=zlm1.prob,
                                    rho_l.ps_zlm1=aperm(rho_l.ps_zlm1, c(3, 1, 2)), 
                                    expectation.zz.given.s.ps_zlm1=aperm(expectation.zz.given.s.ps_zlm1, c(4, 3, 2, 1)), 
                                    eta.list=eta.list,
                                    lambda.list=Lambda.list,
                                    psi.list=psi.list,
                                    pis.list=pis.list,
                                    l=l,
                                    data=data,
                                    ps.y=ps.y,
                                    rot=rot,
                                    rot.type=rot.type,
                                    same.lambda=same.lambda.v)
        }  
        
   
        Lambda.list[[l]] <- out$Lambda
        psi.list[[l]] <- out$psi
        psi.inv.list[[l]] <- out$psi.inv
        eta.list[[l]] <- out$eta
        pis.list[[l]] <- out$pis
        rotations[[l]] <- out$rotations

          
           
        if(rot && !same.lambda.v){
          # it is used for zlm1 but if zl.list is not null, will be replaced
           for(kli in k[l]){
            if(r[l]!=1){
              z.list[[l]][kli,,] <- z.list[[l]][kli,,]  %*% rotations[[l]][kli,,]
            }
            else{
              z.list[[l]][kli,,] <- z.list[[l]][kli,,]  * rotations[[l]][kli,,]
            }
           }
        }
          
    } # end for(l in 1:num.layers){



    lik.out <- compute.likelihood(data=data,
                                  k=k,
                                  eta.list=eta.list,
                                  Lambda.list=Lambda.list,
                                  psi.list=psi.list,
                                  pis.list=pis.list,
                                  iteration=iteration,
                                  nb.burnin=nb.burnin,
                                  strategy.init=strategy.init,
                                  rate.strat=rate.strat)

    py <- lik.out$py
    ps.y <- lik.out$ps.y
    ps.y.list <- lik.out$ps.y.list
    hard.ps.y.list <- lik.out$hard.ps.y.list
    s <- lik.out$s 
    

    # progress bar
    pb$tick()



    lik <- sum(log(py))
    bic <- compute.bic(num.layers, k, R, numobs, lik)
    if(length(true.clust)>1){
      ari <- mclust::adjustedRandIndex(true.clust,max.col(ps.y))
      
      if(verbose==T){
        print(ari)
      }
      aris <- c(aris, mclust::adjustedRandIndex(true.clust,max.col(ps.y)))
    }

    bics <- c(bics, bic)

    params <- list(Lambda = Lambda.list, pis = pis.list, eta = eta.list, psi = psi.list,
              s = s, ps.y = ps.y, z.list=z.list)
    if(ret.params.iterations){
      params.iterations[[iteration]] <- params
    }
    

  } # end of for(iteration in 1:nb.iter)
  

  lik <- sum(log(py))
  bic <- compute.bic(num.layers, k, R, numobs, lik)


  for(l in 1:num.layers){
    
    zl <- matrix(0, numobs, r[l])
  
    for (kli in 1 : k[l]) {
          zl <- zl + matrix(z.list[[l]][kli,,] * array(hard.ps.y.list[[l]][, kli],c(numobs, r[l])), 
                      numobs, r[l])
           
    }
    zl.return[[l]] = zl
  }

  out <- list(Lambda = Lambda.list,
                pis = pis.list,
                eta = eta.list, 
                psi = psi.list,
                s = s, 
                ps.y = ps.y,
                bic = bic,
                aris=aris, 
                bics=bics, 
                params.iterations=params.iterations,
                zl.return=zl.return)
  
  return(out)
  
}
