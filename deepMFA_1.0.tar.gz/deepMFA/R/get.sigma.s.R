get.sigma.s <- function(psi.list,Lambda.list,l,layers,k.comb,i){
	if(layers<l){# in case layers=1
		return(diag(dim(Lambda.list[[l-1]])[2]))
	}
	if(l==layers){
		return(psi.list[[l]][k.comb[i, l],, ] + Lambda.list[[l]][k.comb[i,l],, ] %*% t(Lambda.list[[l]][k.comb[i,l],, ]))	
	}
	else{
		result = psi.list[[l]][k.comb[i, l],, ] + Lambda.list[[l]][k.comb[i,l],, ] %*% 
			get.sigma.s(psi.list,Lambda.list,l+1,layers,k.comb,i) %*%
			t(Lambda.list[[l]][k.comb[i,l],, ])
		return(result)
	}
}