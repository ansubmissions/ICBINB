compute.bic <- function(num.layers, k, R, numobs, lik){
	nu <- 0 # nu = number of parameters
	for (l in 1 : num.layers) {
	  nu <- nu + (k[l] - 1) + (R[l] * R[l + 1]) * k[l] + R[l] * k[l] + k[l] * R[l]
	}
	if (num.layers > 1) {
	  for (l in 2:num.layers) {
	    nu <- nu - (R[l] * k[l] * (R[l] - 1) / 2)
	  }
	}

	bic <- -2 * lik + nu * log(numobs)

	return(bic)
}