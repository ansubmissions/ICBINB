init.mfa.old <- function(data, s, k, r, l){
  
  r_lm1 = dim(data)[2]
  
  psi <- array(0, c(k[l], r_lm1, r_lm1))
  psi.inv <- array(0, c(k[l], r_lm1, r_lm1))
  Lambda <- array(0, c(k[l], r_lm1, r[l]))
  eta <- matrix(0, r_lm1, k[l])
  z <- matrix(NA, nrow = dim(data)[1], ncol = r[l])
  
  for( j in 1:k[l] ){
    indices <- which( s == j )
    f.a <- try(factanal(data[indices,], r[l], rotation = "varimax", scores = "regression"), silent = TRUE)
    
    if ( is.character(f.a) ) {
      psi[j,,] <- 0.1 * diag(r_lm1)
      psi.inv[j,,] <- diag(r_lm1)
      Lambda[j,,] <- matrix(runif(r_lm1 * r[l]), r_lm1, r[l])
      
      zt <- try(princomp(data[indices,])$scores[, 1 : r[l]], silent = TRUE)
      
      if ( !is.character(zt) ) {
        zt <- as.matrix(zt, nrow = length(indices), ncol = r[l])
      } 
      else {
        #zt <- matrix(data[indices, sample(1 : r[l])], nrow = length(indices), ncol = r[l])
        zt <- matrix(data[indices, sample(1 : min(r_lm1,r[l]), r[l], replace=T)], nrow = length(indices), ncol = r[l])
      }
      z[indices, ] <- zt
    }
    else { # if factanal worked
      psi[j,,] <- diag(f.a$uniqueness)
      Lambda[j,,] <- f.a$load
      psi.inv[j,,] <- diag(1/f.a$uniqueness)
      z[indices,] <- f.a$scores
    }
    
    eta[,j] <- colMeans(data[indices,,drop = FALSE])
  } # end for k[l]
  
  pis <- matrix(table(s)/dim(data)[1])
  return(list(pis = pis, Lambda = Lambda, eta = eta, psi = psi, psi.inv = psi.inv, z = z))
  
}