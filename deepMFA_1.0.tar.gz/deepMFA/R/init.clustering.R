init.clustering <- function(data, k, l, init="kmeans"){
  
  s <- sample( 1:k[l], dim(data)[1], replace = T)
  
  
  if ( k[l] == 1 ) {
    s <- rep(1, dim(data)[1])
    return(s)
  }
  
  if ( init == 'kmeans' ){
    s <- kmeans(data, k[l], iter.max = 200, nstart = 30,
                algorithm = "Hartigan-Wong")$cluster
    return(s)
  }

  if ( init == 'mclust' ){
    require(mclust)
    mclust.options(hcUse = "SVD")
    s <- Mclust(data, G=k[l], verbose=FALSE)$cl
    #s <- sample( 1:k, dim(data)[1], replace = T)
    return(s)
  }
  
  if ( init == 'random' ){
    s <- sample( 1:k[l], dim(data)[1], replace = T)
    return(s)
  }
  
  return(s)
  
}
