compute.est <- function(k_l,
                        r_lm1,
                        r_l,
                        ps.y.list_l,
                        zlm1.prob,
                        rho_l.ps_zlm1,
                        expectation.zz.given.s.ps_zlm1,
                        eta.list_l,
                        lambda.list_l,
                        psi.list_l,
                        parsimony="uuu",
                        rot=FALSE,
                        rot.type="procrustes",
                        same.lambda=FALSE,
                        upper.tri.lambda=FALSE,
                        diag.lam.psi.lam=FALSE
                        ){


  
  # (k, p, qq, ps.y, y, Ez, Ezz, mu)
  value <- .Machine$double.eps #1e-20

  for(ki in 1:k_l){
    if(sum(ps.y.list_l[,ki])==0){
      ps.y.list_l[,ki] = value
    }
  }
  
  Lambda <- array(0, c(k_l, r_lm1, r_l))
  eta <- array(0, c(r_lm1, k_l))
  psi <- psi.inv <- array(0, c(k_l, r_lm1, r_lm1))
  numobs <- dim(zlm1.prob)[1]
  pis <- 0


  
  rotations <- array(0, dim=c(k_l, r_l, r_l))
  for (ki in 1 : k_l) {
    
    #if (r_l > 1) {
      EEzz <- apply((expectation.zz.given.s.ps_zlm1[ki,,, ] * (aperm(array(ps.y.list_l[, ki],
                                                                           c(numobs, r_l, r_l)), c(2, 3, 1)))), 1, rowSums) / sum(ps.y.list_l[, ki])

    #}
    #if (r_l == 1) {
    #  EEzz <- expectation.zz.given.s.ps_zlm1[ki,,, ] %*% (ps.y.list_l[, ki]) / sum(ps.y.list_l[, ki])
    #}





      
    if(TRUE==same.lambda){    
        Lambda[ki,, ] <- lambda.list_l[ki,, ]    
    }
    else{
      # me:
      #Lambda[ki,, ] <- (t((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) ) %*%
      #                    (matrix(rho_l.ps_zlm1[ki,, ], nrow = numobs) *
      #                      matrix(ps.y.list_l[, ki], numobs, r_l))) %*% ginv(EEzz) / sum(ps.y.list_l[, ki])
      

      Lambda[ki,, ] <- (t((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) *
                          matrix(ps.y.list_l[,ki], numobs, r_lm1)) %*%
                        (matrix(rho_l.ps_zlm1[ki,, ], nrow = numobs) *
                          matrix(ps.y.list_l[, ki], numobs, r_l))) %*% ginv(EEzz) / sum(ps.y.list_l[, ki])
    
    
    }


    

    #TODO: original
    psi[ki,, ] <- (t((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) *
                       matrix(ps.y.list_l[, ki], numobs, r_lm1)) %*%
                     (matrix((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) *
                              matrix(ps.y.list_l[, ki], numobs, r_lm1), ncol = r_lm1)) -
                     t((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) *
                         matrix(ps.y.list_l[, ki], numobs, r_lm1)) %*%
                     (matrix(rho_l.ps_zlm1[ki,, ], nrow = numobs) *
                        matrix(ps.y.list_l[, ki], numobs, r_l)) %*% t(Lambda[ki,, ]))
   

    #psi[ki,, ] <- t(zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs)))  %*%
    #                 (matrix((zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) *
    #                           matrix(ps.y.list_l[, ki], numobs, r_lm1), ncol = r_lm1)) -
    #                 t(zlm1.prob - t(matrix(eta.list_l[, ki], r_lm1, numobs))) %*%
    #                 (matrix(rho_l.ps_zlm1[ki,, ], nrow = numobs) *
    #                    matrix(ps.y.list_l[, ki], numobs, r_l)) %*% t(Lambda[ki,, ])  
    
    
    psi[ki,, ] <- psi[ki,,, drop = FALSE] / sum(ps.y.list_l[, ki])
    psi[ki,, ] <- ifelse((psi[ki,, ] == 0), value, psi[ki,, ])


    
    if (r_lm1 > 1) {
      psi[ki,, ] <- diag(diag(psi[ki,, ]))
      psi.inv[ki,, ] <- diag(1/diag(psi[ki,, ]))
    }
    psi[ki,, ]  <- ifelse(is.na(psi[ki,, ]), 1, psi[ki,, ])
    psi.inv[ki,, ] <- ifelse(is.na(psi.inv[ki,, ]), 1, psi.inv[ki,, ])


    if(rot && !same.lambda){
      if(rot.type=="varimax"){   
        varim <- varimax(Lambda[ki,, ], normalize=FALSE, eps=0.01)
        Lambda[ki,, ] <- varim$loadings
        rotations[ki,,] <- varim$rotmat
      }
      if(rot.type=="procrustes"){
        proc <- vegan::procrustes(lambda.list_l[ki,,], Lambda[ki,,], scale = FALSE, symmetric = FALSE)
        Lambda[ki,,] <- Lambda[ki,,] %*% proc$rotation    
        rotations[ki,,] <- proc$rotation
      }
    }

    if(TRUE==upper.tri.lambda){
      Lambda[ki,, ][upper.tri(Lambda[ki,, ])] <- 0
    }

    if(TRUE==diag.lam.psi.lam && !same.lambda){
      #print(psi[ki,,])
      S=t(Lambda[ki,, ])%*%solve(psi[ki,,])%*%Lambda[ki,, ]
      Lambda[ki,, ]=Lambda[ki,, ]%*%eigen(S)$vectors
    }
    

    eta[, ki] <- colSums(matrix(ps.y.list_l[, ki], numobs, r_lm1) *
                           (zlm1.prob - t(matrix(Lambda[ki,,], ncol = r_l) %*%
                                            t(rho_l.ps_zlm1[ki,, ]))))/sum(ps.y.list_l[, ki])




    pis[ki] <- mean(ps.y.list_l[, ki])
    
  } # end for (ki in 1 : k_l) {


  
  return(list(Lambda = Lambda, eta = eta, psi = psi, psi.inv = psi.inv, pis = pis, rotations=rotations))
  
}