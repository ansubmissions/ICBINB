compute.est.newton <- function(k,
                              R,
                              r,
                              ps.y.list,
                              zlm1.prob,
                              rho_l.ps_zlm1,
                              expectation.zz.given.s.ps_zlm1,
                              eta.list, 
                              lambda.list,
                              psi.list,
                              pis.list,
                              l,
                              data,
                              ps.y,
                              rot=FALSE, 
                              rot.type="procrustes",
                              same.lambda=FALSE){

  
  eta.list_l <- eta.list[[l]]
  lambda.list_l <- lambda.list[[l]]
  psi.list_l <- psi.list[[l]]
  ps.y.list_l <- ps.y.list[[l]]
  k_l <- k[l]
  r_lm1 <- R[l]
  r_l <- r[l]



  # (k, p, qq, ps.y, y, Ez, Ezz, mu)
  value <- .Machine$double.eps #1e-20

  for(ki in 1:k_l){
    if(sum(ps.y.list_l[,ki])==0){
      ps.y.list_l[,ki] = value
    }
  }
  
  Lambda <- array(0, c(k_l, r_lm1, r_l))
  eta <- array(0, c(r_lm1, k_l))
  psi <- psi.inv <- array(0, c(k_l, r_lm1, r_lm1))
  numobs <- dim(zlm1.prob)[1]
  pis <- 0

  


  hard.ps.y.list_l <- t(apply(ps.y.list_l, 1, function(x){
            ret<- rep(0,k_l);
            ret[which.max(x)]=1;
            return(ret);
          }
        )
    )

  rotations <- array(0, dim=c(k_l, r_l, r_l))
  for (ki in 1 : k_l) {



    if(TRUE==same.lambda){    
      Lambda[ki,, ] <- lambda.list_l[ki,, ]    
    }
    else{
      
      # flatten lambda
      lambda <- as.vector(lambda.list_l[ki,,])
      optimisation <- optimLambda(logpdf, lambda, data, eta.list, lambda.list, psi.list, pis.list, k, ki, l, ps.y, r_lm1)
      
      lambda.opt.flat <- optimisation$mode
      Lambda[ki,, ] <- matrix(lambda.opt.flat, nrow=r_lm1) 

    }
      
    psi[ki,, ] <- diag(r_lm1)
    psi.inv[ki,, ] <- diag(r_lm1)


    if(rot){
      if(rot.type=="varimax"){   
        varim <- varimax(Lambda[ki,, ], normalize=FALSE, eps=0.01)
        Lambda[ki,, ] <- varim$loadings
        rotations[ki,,] <- varim$rotmat
      }
      if(rot.type=="procrustes"){
        proc <- vegan::procrustes(lambda.list_l[ki,,], Lambda[ki,,], scale = FALSE, symmetric = FALSE)
        Lambda[ki,,] <- Lambda[ki,,] %*% proc$rotation    
        rotations[ki,,] <- proc$rotation
      }
    }
    #Lambda[ki,, ][upper.tri(Lambda[ki,, ])] <- 0


    eta[, ki] <- colSums(matrix(ps.y.list_l[, ki], numobs, r_lm1) *
                           (zlm1.prob - t(matrix(Lambda[ki,,], ncol = r_l) %*%
                                            t(rho_l.ps_zlm1[ki,, ]))))/sum(ps.y.list_l[, ki])



    # TODO!
    pis[ki] <- mean(ps.y.list_l[, ki])
    
  } # end for (ki in 1 : k_l) {





  
  return(list(Lambda = Lambda, eta = eta, psi = psi, psi.inv = psi.inv, pis = pis, rotations=rotations))
  
}