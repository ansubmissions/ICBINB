get.k.comb <- function(k){
	k.comb <- apply(t(k), 2, function(x) 1 : x)
	if (is.list(k.comb)) {
	  #print("test1")
	  k.comb <- expand.grid(k.comb)
	  k.comb <- matrix(unlist(k.comb), ncol = length(k))
	}
	else if (is.matrix(k.comb)) {
	  #print("test2")
	  k.comb <- expand.grid(split(t(k.comb), 1 : ncol(k.comb)))
	  k.comb <- matrix(unlist(k.comb), ncol = length(k))
	}
	if (prod(k) == 1) {
	  #print("test3")
	  k.comb <- matrix(k.comb, nrow =1)
	}
	return(k.comb)
}

