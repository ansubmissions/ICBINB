logpdf <- function(lambda, data, eta.list, lambda.list, psi.list, pis.list, k, ki, l.opt, ps.y, rlm1,verbose=FALSE){

  # TODO 
  #sigma.tot <- diag(ncol(data))
  #mu.tot <- rep(0, ncol(data))
  lambda <- matrix(lambda, nrow=rlm1) 

  layers <- length(k)
  p <- ncol(data)
  numobs <- nrow(data)
  py <- matrix(0, numobs) # p(y)
  tot.k <- prod(k)  
  k.comb <- get.k.comb(k)

  prob <- 0

  
  
  for (i in 1 : tot.k)  {
    
    # TODO ORIGINAL
    #eta.tot <- eta.list[[1]][, k.comb[i, 1]]
    sigma.tot <- psi.list[[1]][k.comb[i, 1],, ]
    pis.tot <- pis.list[[1]][k.comb[i, 1]]


    # Recusrivity could be down 1 level
    eta.tot <- #eta.list[[1]][, k.comb[i, 1]] + lambda.list[[1]][k.comb[i,1],, ] %*% 
      get.eta.s(eta.list,lambda.list,l=1,layers,k.comb,i)

  
    
    if(length(which(is.nan(sigma.tot)))>0){
          sigma.tot = diag(p)
    }
    if (layers > 1) {
      for (l in 2 : layers) {
        
        # TODO ORIGINAL
        tot.Lambda <- diag(p)
        for (m in 1 : (l - 1)) {
          lambda.tmp <- lambda.list[[m]][k.comb[i, m],, ]
          if(m==l.opt && k.comb[i, m]==ki){
            lambda.tmp <- lambda
          }
          tot.Lambda <- tot.Lambda %*% lambda.tmp
        }

        lambda.tmp <- lambda.list[[l]][k.comb[i, l],, ]
        if(l==l.opt && k.comb[i, l]==ki){
          lambda.tmp <- lambda
        }
        sigma.tot <- sigma.tot + tot.Lambda %*% (lambda.tmp %*%
                                                   t(lambda.tmp) +
                                                   psi.list[[l]][k.comb[i, l],, ]) %*% t(tot.Lambda)
        if(length(which(is.nan(sigma.tot)))>0){
          sigma.tot = diag(p)
        }
        pis.tot <- pis.tot * pis.list[[l]][k.comb[i, l]]
      }
    }

    
    #if (!corpcor::is.positive.definite(sigma.tot)) {
    #  sigma.tot <- corpcor::make.positive.definite(sigma.tot)
    #}
    #if (!isSymmetric(sigma.tot)) {
    #  sigma.tot <- makeSymm(sigma.tot)
    #}

    maxim <- apply(ps.y, 1, which.max)
    #print(which(maxim==i))
    x <- data[which(maxim==i),]
    #print(x)
    prob <- prob + sum(mvtnorm::dmvnorm(x, eta.tot, sigma.tot, log = TRUE))
  } # end for (i in 1 : tot.k)  {
  

  return(prob)
}