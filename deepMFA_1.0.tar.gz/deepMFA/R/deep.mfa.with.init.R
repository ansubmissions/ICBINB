deep.mfa.with.init <- function(data, k, r, num.layers, nb.iter, init="kmeans", 
  init.pam=0, init.clust=0, init.s=0, want.it=TRUE, true.clust=0, verbose=FALSE,
  parsimony="uuu"){
  
  pb <- progress::progress_bar$new(total = nb.iter+2)
  
  numobs <- nrow(data)
  p <- ncol(data)
  R <- c(p,r)
  # we have r = c(dim1, dim2,...,dimh)
  # and R = c(dim0, dim1,...,dimh) with dim0 = p
  
  ### INITIALIZATION #### init Lambda, psi, eta, z what about s?
  lst <- list(pis = list(), Lambda = list(), eta = list(), psi = list(), psi.inv = list(), z = list()) # z to delete afterwards
  
  params.iterations <- vector("list", length = nb.iter)
  zl.return <- vector("list", length = num.layers)
  
  for (l in 1 : num.layers) {
    #if (l == 1) {
    #  z_l <- data
    #} 
    #else {
    #  z_l <- z[, 1 : r[l-1], drop = FALSE]
    #}
    
    # provide initial parititioning of the observations
    
    #s <- init.clust#init.clustering(z_l, k, l, init)
    
    # initialize parameters using factor analysis of covariance matrix
    
    #lst_l <- init.mfa(z_l, s, k, r, l)
    
    lst$pis[l] <- list(init.pam$pis[[l]])
    lst$Lambda[l] <- list(init.pam$Lambda[[l]])
    lst$eta[l] <- list(init.pam$eta[[l]])
    lst$psi[l] <- list(init.pam$psi[[l]])
    lst$psi.inv[l] <- list(init.pam$psi.inv[[l]])
    #lst$z[l] <- list(init.pam$z.list[[l]])
    #z <- init.pam$z.list[[l]]
    #lst$z[l] <- list(lst_l$z)
    #z <- lst_l$z
    
  }
  
  # progress bar
  pb$tick()

  aris <- c()
  bics <- c()
  
  pis.list = lst$pis
  psi.list = lst$psi
  psi.inv.list = lst$psi.inv
  eta.list = lst$eta
  Lambda.list = lst$Lambda
  #z.list = lst$z # TODO: see what's happening there
  
  out <- compute.likelihood(data, k, eta.list, Lambda.list, psi.list, pis.list,iteration,nb.iter)
  py <- out$py
  ps.y <- out$ps.y
  ps.y.list <- out$ps.y.list
  s <- out$s 
  
  z.list <- NULL # TODO: see what's happening there
  
  ### SEM ALGORITHM ####
  
  # progress bar
  pb$tick()

  if(want.it){
    for(iteration in 1:nb.iter){
      
      #print(paste("iter = ", iteration))
      for(l in 1:num.layers){
        #print(paste("l  = ", l))
        
        zlm1 <- matrix(0, numobs, R[l])
        zlm1.prob <- matrix(0, numobs, R[l])
        if(1==l){
          zlm1 <- data
          zlm1.prob <- data
        }
        else{
          zlm1 <- z.list[[l - 1]]
          zlm1.prob <- matrix(0, numobs, R[l])
          for (klm1i in 1 : k[l - 1]) {
            zlm1.prob <- zlm1.prob + matrix(zlm1[klm1i,,] *
                                              array(ps.y.list[[l - 1]][, klm1i],
                                                    c(numobs, R[l])), numobs, R[l])
          }
        }
        
        rho_l <- array(0, c(numobs, r[l], k[l:num.layers])) # \rho_{k_l...k_h}
        sample.z_l <- array(0, c(numobs, r[l], k[l:num.layers])) # sample N(0, \zeta_{k_l...k_h}) + \rho_{k_l...k_h}
        expectation.zz.given.s <- array(0, c(numobs, r[l], r[l], k[l:num.layers])) # \rho_{k_l...k_h} x \rho_{k_l...k_h}^T + \zeta_{k_l...k_h}
        
        rho_l.ps_zlm1 <- array(0, c(numobs, r[l], k[l]))
        sample.z_l.ps_zlm1 <- array(0, c(numobs, r[l], k[l]))
        expectation.zz.given.s.ps_zlm1 <- array(0, c(numobs, r[l], r[l], k[l]))
        
        
        ### computing \rho, \rho * \rho^t and zeta for each path
        k.prod = prod(k[l:num.layers])
        k.comb = get.k.comb(k[l:num.layers])
        kis <- rep(0,num.layers-l+1)
        for(k.iter in 1:k.prod){
          # here, we are in one path, to know which one, we compute kis
          row.index = k.iter %% k.prod + 1
          icount = 1
          for(layeri in (1:(num.layers-l+1)) ){
            kis[icount] <- k.comb[row.index,layeri]
            icount <- icount + 1
          }
          
          
          # computing sigma.tilde 
          sigma.tilde = get.sigma.tilde(psi.list, Lambda.list, r, kis, l, num.layers)
          mu.tilde  = get.mu.tilde(eta.list, Lambda.list, r, kis, l, num.layers)


          zeta.inv = ginv(sigma.tilde) + 
            t(Lambda.list[[l]][kis[1],,]) %*% 
            ginv(psi.list[[l]][kis[1],,]) %*% 
            Lambda.list[[l]][kis[1],,]
       

          zeta = ginv(zeta.inv)


          
          if (!isSymmetric(zeta)) {
            zeta <- makeSymm(zeta)
          }
          if (!is.positive.definite(zeta)) {
            zeta <- make.positive.definite(zeta)
          }
          # \rho = \zeta %*% [expression], expression = b
          b = t(Lambda.list[[l]][kis[1],,]) %*% 
            ginv(psi.list[[l]][kis[1],,]) %*%
            ( t(zlm1.prob) - matrix(eta.list[[l]][,kis[1]], R[l], numobs) ) + # here using R makes sense bc we need r[l-1]
            ginv(sigma.tilde) %*% matrix(mu.tilde, r[l], numobs)
          
          rho = zeta %*% b
          rho.rhot = array(apply(rho, 2, function(x) x %*% t(x)),
                           c(r[l], r[l], numobs))
          
          
          ## expectation.zz.given.s 
          ARGS <- vector("list", length = length(dim(expectation.zz.given.s)))
          ARGS[[1]] <- 1:numobs
          ARGS[[2]] <- 1:r[l]
          ARGS[[3]] <- 1:r[l]
          ARGS[4:length(ARGS)] <- kis
          aperm.zeta.rhorhot <- aperm(array(zeta,c(r[l], r[l], numobs)) +
                                        rho.rhot, c(3, 1, 2))
          expectation.zz.given.s.tmp <- expectation.zz.given.s
          expectation.zz.given.s <- do.call("[<-", c(list(expectation.zz.given.s.tmp),ARGS,list(aperm.zeta.rhorhot)))
          
          ## sample.z_l
          ARGS <- vector("list", length = length(dim(sample.z_l)))
          ARGS[[1]] <- 1:numobs
          ARGS[[2]] <- 1:r[l]
          ARGS[3:length(ARGS)] <- kis
          rmvnorm.rho <- mvtnorm::rmvnorm(numobs, rep(0, r[l]), zeta) + t(rho)
          sample.z_l.tmp <- sample.z_l 
          sample.z_l <- do.call("[<-", c(list(sample.z_l.tmp),ARGS,list(rmvnorm.rho)))
          
          ## rho_l
          ARGS <- vector("list", length = length(dim(rho_l)))
          ARGS[[1]] <- 1:numobs
          ARGS[[2]] <- 1:r[l]
          ARGS[3:length(ARGS)] <- kis
          rho_l.tmp <- rho_l
          rho_l <- do.call("[<-", c(list(rho_l.tmp),ARGS,list(t(rho)))) 
          


          if(l == num.layers){
            rho_l.ps_zlm1[,,kis] <- t(rho)
            sample.z_l.ps_zlm1[,,kis] <- rmvnorm.rho 
            expectation.zz.given.s.ps_zlm1[,,,kis] <- aperm.zeta.rhorhot
          }
          
        } # end for(k.iter in 1:k.prod){ --> is equivalent to several loops on all ki of k
        
        
        # filling with probs:
        
        if(l != num.layers){
          
          k.prod = prod(k[(l+1):num.layers])
          k.comb = get.k.comb(k[(l+1):num.layers])
          kis <- rep(0,num.layers-l)
          for(k.iter in 1:k.prod){
            row.index = k.iter %% k.prod + 1
            icount = 1
            for(layeri in (1:(num.layers-l)) ){
              kis[icount] <- k.comb[row.index,layeri]
              icount <- icount + 1
            }
            prob <- get.prob.ps.y(ps.y.list, kis, l, num.layers)
            #print("prob")
            #print(prob)
            #print(dim(prob))
            ## rho_l
            ARGS <- vector("list", length = length(dim(rho_l)) )
            ARGS[[1]] <- 1:numobs
            ARGS[[2]] <- 1:r[l]
            ARGS[[3]] <- 1:k[l]
            ARGS[4:length(ARGS)] <- kis
            
            rho_l.tmp <- do.call("[", c(list(rho_l),ARGS))
            rho_l.ps_zlm1 <- rho_l.ps_zlm1 + rho_l.tmp * array( rowSums(prob), c(numobs, r[l], k[l]) )
            
            # sample.z_l
            ARGS <- vector("list", length = length(dim(sample.z_l)) )
            ARGS[[1]] <- 1:numobs
            ARGS[[2]] <- 1:r[l]
            ARGS[[3]] <- 1:k[l]
            ARGS[4:length(ARGS)] <- kis
            
            sample.z_l.tmp <- do.call("[", c(list(sample.z_l),ARGS))
            sample.z_l.ps_zlm1 <- sample.z_l.ps_zlm1 + sample.z_l.tmp * array( rowSums(prob), c(numobs, r[l], k[l]) )
            
            
            # expectation.zz.given.s
            ARGS <- vector("list", length = length(dim(expectation.zz.given.s)) )
            ARGS[[1]] <- 1:numobs
            ARGS[[2]] <- 1:r[l]
            ARGS[[3]] <- 1:r[l]
            ARGS[[4]] <- 1:k[l]
            ARGS[5:length(ARGS)] <- kis
            
            expectation.zz.given.s.tmp <- do.call("[", c(list(expectation.zz.given.s),ARGS))
            expectation.zz.given.s.ps_zlm1 <- expectation.zz.given.s.ps_zlm1 + 
              expectation.zz.given.s.tmp * array( rowSums(prob), c(numobs, r[l], r[l], k[l]) )
            
            
          } # end of second for(k.iter in 1:k.prod){
          
        } # end of if(l != num.layers){
        
        z.list[[l]] <- aperm(sample.z_l.ps_zlm1, c(3, 1, 2))
        out  <- compute.est(k[l], 
                            R[l], 
                            r[l], 
                            ps.y.list[[l]], 
                            zlm1.prob, # TODO: CHANGE
                            aperm(rho_l.ps_zlm1, c(3, 1, 2)), 
                            aperm(expectation.zz.given.s.ps_zlm1, c(4, 2, 3, 1)), 
                            eta.list[[l]],
                            parsimony=parsimony,
                            Lambda.list[[l]],
                            psi.list[[l]]
                            )
        
        Lambda.list[[l]] <- out$Lambda
        psi.list[[l]] <- out$psi
        psi.inv.list[[l]] <- out$psi.inv
        eta.list[[l]] <- out$eta
        pis.list[[l]] <- out$pis


        rotations <- out$rotations
        for(kli in k[l]){
          z.list[[l]][kli,,] <- z.list[[l]][kli,,] %*% rotations[kli,,] 
        }
        
        
      } # end for(l in 1:num.layers){
      
      
      out <- compute.likelihood(data, k, eta.list, Lambda.list, psi.list, pis.list)
      py <- out$py
      ps.y <- out$ps.y
      ps.y.list <- out$ps.y.list
      hard.ps.y.list <- out$hard.ps.y.list
      s <- out$s 
      
      # progress bar
      pb$tick()


      if(length(true.clust)>1){
        ari <- mclust::adjustedRandIndex(true.clust,max.col(ps.y))
        lik <- sum(log(py))
        bic <- compute.bic(num.layers, k, R, numobs, lik)
        if(verbose==T){
          print(ari)
        }
        aris <- c(aris, mclust::adjustedRandIndex(true.clust,max.col(ps.y)))
        bics <- c(bics, bic)
      }

      params <- list(Lambda = Lambda.list, pis = pis.list, eta = eta.list, psi = psi.list,
              s = s, ps.y = ps.y, z.list=z.list)
      params.iterations[[iteration]] <- params
    } # end of for(iteration in 1:nb.iter)

  } # end if want.it
  
  
  

  lik <- sum(log(py))
  bic <- compute.bic(num.layers, k, R, numobs, lik)

  for(l in 1:num.layers){
    #print(paste("l  = ", l))
    
    zl <- matrix(0, numobs, r[l])
  
    for (kli in 1 : k[l]) {
          zl <- zl + matrix(z.list[[l]][kli,,] * array(hard.ps.y.list[[l]][, kli],c(numobs, r[l])), 
                      numobs, r[l])
           
    }
    zl.return[[l]] = zl
  }

  out <- list(Lambda = Lambda.list, pis = pis.list, eta = eta.list, psi = psi.list, psi.inv = psi.inv.list,
              s = s, ps.y = ps.y, bic = bic, z.list=z.list, aris=aris, bics=bics, 
              params.iterations=params.iterations, zl.return=zl.return)
  
  return(out)
  
}
