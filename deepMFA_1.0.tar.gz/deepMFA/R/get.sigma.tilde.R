get.sigma.tilde <- function(psi.list, Lambda.list, r, kis, l, num.layers){
  # We have to know s ! 
  if ( l == num.layers ){
    sigma.tilde <- diag(r[l])
    return(sigma.tilde)
  }
  else{
    sigma.tilde <- array(0, c(r[l], r[l]))
    kp1i <- kis[2]

    #print("l")
    #print(l)
    #print("kp1i")
    #print(kp1i)
    #print("kis")
    #print(kis)
    #print("dim(Lambda.list[[l+1]])")
    #print(dim(Lambda.list[[l+1]])) 
    #print("typeof(Lambda.list)")
    #print(typeof(Lambda.list[[l+1]])) 

    #print("Lambda.list[[l+1]][1,,]")
    #print(Lambda.list[[l+1]][1,,])


    sigma.tilde <- sigma.tilde + Lambda.list[[l+1]][kp1i,,] %*% 
      get.sigma.tilde(psi.list, Lambda.list, r, kis[-1], l+1, num.layers) %*% 
      t(Lambda.list[[l+1]][kp1i,,]) + 
      psi.list[[l+1]][kp1i,,] 
    return(sigma.tilde)
  }
  
}
