get.prob.ps.y <- function(ps.y.list, kis, l, num.layers){
  if(l==num.layers){
    return(array(1,c(dim(ps.y.list[[l]])[1],1))) # dim(ps.y.list[[l]][1] = numobs
  }
  if(l==(num.layers-1)){
    #result <- t(apply(ps.y.list[[l+1]], 1, function(x){
    #    idx.max <- which.max(x)
    #    res <- rep(0, length(x))
    #    res[idx.max] <- 1
    #    res
    #  }))
    #return(result[,kis[1],drop=FALSE])
    return(ps.y.list[[l+1]][, kis[1], drop = FALSE])
  }
  else{
    result = ps.y.list[[l+1]][, kis[1], drop = FALSE] * 
      get.prob.ps.y(ps.y.list, kis[2:length(kis)], l+1, num.layers)
    return(result)
  }
}