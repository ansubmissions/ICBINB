compute.likelihood <- function(data,
                               k,
                               eta.list,
                               Lambda.list,
                               psi.list,
                               pis.list,
                               iteration=0,
                               nb.burnin=0,
                               strategy.init=FALSE,
                               rate.strat=0) {
  
  layers <- length(k)
  p <- ncol(data)
  numobs <- nrow(data)
  py <- matrix(0, numobs) # p(y)
  tot.k <- prod(k)
  py.s <- matrix(0, numobs, tot.k) # p(y|s)
  pys <- matrix(0, numobs, tot.k) # p(y,s)
  
  k.comb <- get.k.comb(k)
  
  
  for (i in 1 : tot.k)  {
    
    #eta.tot <- eta.list[[1]][, k.comb[i, 1]]
    sigma.tot <- psi.list[[1]][k.comb[i, 1],, ]
    pis.tot <- pis.list[[1]][k.comb[i, 1]]


    # Recusrivity could be down 1 level
    eta.tot <- #eta.list[[1]][, k.comb[i, 1]] + Lambda.list[[1]][k.comb[i,1],, ] %*% 
      get.eta.s(eta.list,Lambda.list,l=1,layers,k.comb,i)

    #my.sigma.tot <- psi.list[[1]][k.comb[i, 1],, ] + Lambda.list[[1]][k.comb[i,1],, ] %*%
    #  get.sigma.s(psi.list,Lambda.list,l=2,layers,k.comb,i) %*% t(Lambda.list[[1]][k.comb[i,1],, ])
    
    if(length(which(is.nan(sigma.tot)))>0){
          sigma.tot = diag(p)
    }
    if (layers > 1) {
      for (l in 2 : layers) {
        
        tot.Lambda <- diag(p)
        for (m in 1 : (l - 1)) {
          tot.Lambda <- tot.Lambda %*% Lambda.list[[m]][k.comb[i, m],, ]
        }
        
        #eta.tot <- eta.tot + tot.Lambda %*% eta.list[[l]][, k.comb[i, l]]

        sigma.tot <- sigma.tot + tot.Lambda %*% (Lambda.list[[l]][k.comb[i, l],, ] %*%
                                                   t(Lambda.list[[l]][k.comb[i, l],, ]) +
                                                   psi.list[[l]][k.comb[i, l],, ]) %*% t(tot.Lambda)
        if(length(which(is.nan(sigma.tot)))>0){
          sigma.tot = diag(p)
        }
        pis.tot <- pis.tot * pis.list[[l]][k.comb[i, l]]
      }
    }

    
    if (!corpcor::is.positive.definite(sigma.tot)) {
      sigma.tot <- corpcor::make.positive.definite(sigma.tot)
    }
    if (!isSymmetric(sigma.tot)) {
      sigma.tot <- makeSymm(sigma.tot)
    }
    py.s[,i] <- mvtnorm::dmvnorm(data, c(eta.tot), as.matrix(sigma.tot), log = TRUE)
    

    if(is.na(pis.tot) || pis.tot == 0) {
      pis.tot <-  10^(-1)
    }
    pys[, i] <- log(pis.tot) + py.s[, i]
  }
  
  pys_max <- apply(pys, 1, max) 
  pys <- sweep(pys, 1, pys_max, '-') 
  pys <- exp(pys)
  ps.y <- sweep(pys, 1, rowSums(pys), '/') # p(s | y)
  py <- exp(pys_max) * rowSums(pys)
  
  
  ###### TRYING TO AVOID EMPTY CLUSTERS #######
  if(strategy.init){
    tmp.avoid <- apply(ps.y, 1, which.max)
    if((length(unique(tmp.avoid))<tot.k) && (iteration < nb.burnin)){
      # how many clusters are missing
      not.present <- (1:tot.k)[-unique(tmp.avoid)]
      nb.sample <- ceiling(rate.strat*numobs*length(not.present)/tot.k)
      idx.sample <- sample(1:numobs, nb.sample, replace=F)
      sample.not.present <- sample(not.present, nb.sample, replace=T)
      encoding <- matrix(0, nrow=length(idx.sample), ncol = tot.k)

      for(i.np in not.present){
       encoding[which(sample.not.present==i.np), i.np] <- 1
       ps.y[idx.sample[which(sample.not.present==i.np)],] <- encoding[which(sample.not.present==i.np),]
      }    
    }
  }
  ###### END TRYING TO AVOID EMPTY CLUSTERS#######
  
  
  s <- matrix(0, nrow = numobs, ncol = layers)
  ps.y.list <- NULL
  hard.ps.y.list <- NULL
  for (l in 1 : layers)  {
    
    psi.y <- matrix(0, nrow = numobs, ncol = k[l])
    for (i in 1 : k[l]) {
      
      index <- (k.comb[, l] == i)
      psi.y[, i] <- rowSums(ps.y[, index, drop = FALSE])
  
    }

    s[, l] <- apply(psi.y, 1, which.max)
    ps.y.list[[l]] <- psi.y


    
    hard.ps.y.list[[l]] <- t(apply(ps.y.list[[l]], 1, function(x){
        idx.max <- sample(1:k[l],1,prob=x)
        res <- rep(0, length(x))
        res[idx.max] <- 1
        res
    }))


  } # end for (l in 1 : layers)  {



  

  
  return(list(py = py, py.s = py.s, ps.y = ps.y, k.comb = k.comb,
              s = s, ps.y.list = ps.y.list, hard.ps.y.list = hard.ps.y.list))
}